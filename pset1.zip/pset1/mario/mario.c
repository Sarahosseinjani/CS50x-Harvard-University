#include <stdio.h>
#include <cs50.h>

void print(int);
int main(void)
{
    int Height = get_int("Height:");

    while (Height < 1 || Height > 8)
    {
        Height = get_int("Height:");   
    }
       
    print(Height);
    
}
void print(int H)
{
    int i, j, k;
    for (i = H; i >= 1; i--)
    {
        for (j = 1; j < i; j++)
        {
            printf(" "); 
        }
        for (k = H; k >= i ; k--)
        {
            printf("#");
        }
        printf("  ");
        for (k = H; k >= i ; k--)
        {
            printf("#");
        }
        printf("\n");
    }  
}