#include <stdio.h>
#include <cs50.h>
#include <math.h>
void find(float);
int main(void)
{
    float dollars = get_float("Change owed:"); 
    while (dollars <= 0)
    {
        dollars = get_float("Change owed:");   
    }
       
    find(dollars);
    
}
 
void find(float d)
{
    int cents = round(d * 100);
    int coins[4] = {1, 5, 10, 25}; 
    int i, k = 0, count = 0;
    for (i = 3; i >= 0; i--) 
    { 
        while (cents >= coins[i])
        { 
            cents -= coins[i]; 
            count++;
        } 
    }
    printf("%i\n", count);
}