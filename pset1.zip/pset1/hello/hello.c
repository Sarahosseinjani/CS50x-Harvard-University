#include <stdio.h>
#include <cs50.h>

int main(void)
{
    string name = get_string("What is your name?\n");  //print what is your name and get answer
    printf("hello, %s\n", name);                       // print hello and answer
}