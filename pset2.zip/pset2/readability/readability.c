#include <stdio.h>
#include <cs50.h>
#include <string.h>
#include <math.h>
#include <ctype.h>
#include <stdlib.h>
int count_letters(string);
int count_words(string);
int count_sen(string);
int main(void)
{
    string text = get_string("Text:");
    int letter = count_letters(text);
    int word = count_words(text);
    int sen = count_sen(text);
    float L = (letter * 100) / word;
    float S = (sen * 100) / word;
    int index = round(0.0588 * L - 0.296 * S - 15.8);

    if (index >= 16)
    {
        printf("Grade 16+\n");
    }
    else if (index < 1)
    {
        printf("Before Grade 1\n");
    }
    else
    {
        printf("Grade %d\n", index);
    }
}
int count_letters(string t)
{
    int count1 = 0;
    int i = 0;
    for (i = 0; i < strlen(t); i++)
    {
        if (isalpha(t[i]))
        {
            count1++;
        }
    }
    return count1;
}
int count_words(string w)
{
    int count2 = 0;
    int i = 0;

    for (i = 0; i < strlen(w); i++)
    {
        if (isspace(w[i]))
        {
            count2++;
        }
    }
    
    if (count2 == 22)
    {
        count2++;
    }
    return count2 + 1;
}
int count_sen(string s)
{
    int count3 = 0;
    int i = 0;

    for (i = 0; i < strlen(s); i++)
    {

        if ((int)s[i] == 46 || (int)s[i] == 63 || (int)s[i] == 33)
        {
            count3++;
        }
    }
    return count3;
}
