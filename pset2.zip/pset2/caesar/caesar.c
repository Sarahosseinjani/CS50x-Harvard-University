#include <string.h>
#include <cs50.h>
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
int main(int argc, string argv[])
{
    if (argc == 2 && atoi(argv[1]) != 2)
    {
        string plain = get_string("plaintext:  ");
        int k = atoi(argv[1]);
        char c[1000];
        printf("ciphertext: ");
        for (int i = 0; i < strlen(plain); i++)
        {
            if (islower(plain[i]))
            {
                c[i] = (char)((int)plain[i] + k - 97) % 26;
                printf("%c", c[i] + 97);
            }
            else if (isupper(plain[i]))
            {
                c[i] = (char)((int)plain[i] + k - 65) % 26;
                printf("%c", c[i] + 65);
            }
            else
            {
                c[i] = plain[i];
                printf("%c", c[i]);
            }
           
        }
        printf("\n");
        
    }
    
    else
    {
        printf("Usage: %s\n", argv[0]);
        return 1;
    }
    return 0;
    
}