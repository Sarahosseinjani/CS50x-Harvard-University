from cs50 import get_string

text = get_string("Text: \n")

letter = 0
word = 0
sen = 0
count = 0

for i in text:
    count += 1

for i in range(count):
    
    if (ord(text[i]) >= 65 and ord(text[i]) <= 122):
        letter += 1

    elif (ord(text[i]) == 32 and (ord(text[i - 1]) != 33 and ord(text[i - 1]) != 46 and ord(text[i - 1]) != 63)):
        word += 1

    elif (ord(text[i]) == 33 or ord(text[i]) == 46 or ord(text[i]) == 63):
        sen += 1
        word += 1  # last word in sentence

L = letter * 100 / word
S = sen * 100 / word

index = round(0.0588 * L - 0.296 * S - 15.8)

if (index < 1):
    print("Before Grade 1")

elif (index >= 16):
    print("Grade 16+")

else:
    print(f"Grade {index}")