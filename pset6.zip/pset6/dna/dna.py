from csv import reader, DictReader
from sys import argv

if len(argv) < 3:
    print("python dna.py data.csv sequence.txt")
    exit()

with open(argv[2]) as sequencefile:
    sequence = reader(sequencefile)
    for row in sequence:
        dnalist = row

dna = dnalist[0]
seq = {}

with open(argv[1]) as datafile:
    people = reader(datafile)
    for row in people:
        dnaSequences = row
        dnaSequences.pop(0)
        break

for item in dnaSequences:
    seq[item] = 1

for key in seq:
    l = len(key)
    maxi = 0
    STR = 0
    for i in range(len(dna)):
        while (STR > 0):
            STR -= 1
            continue

        if dna[i: i + l] == key:
            while dna[i - l: i] == dna[i: i + l]:
                STR += 1
                i += l
            if STR > maxi:
                maxi = STR
    seq[key] += maxi

with open(argv[1], newline='') as datafile:
    people = DictReader(datafile)
    for person in people:
        match = 0
        for dna in seq:
            if seq[dna] == int(person[dna]):
                match += 1
        if match == len(seq):
            print(person['name'])
            exit()

    print("No match")