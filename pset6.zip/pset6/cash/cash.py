from cs50 import get_float

cash = 0
while (cash <= 0):
    cash = get_float("Change owed: ")

quarter = 0
coin = 0
nickle = 0
peni = 0
coins = 0
cents = round(cash * 100, 0)
while (cents > 0):
    if (cents >= 25):
        cents -= 25
        quarter += 1
    elif (cents >= 10):
        cents -= 10
        coin += 1
    elif (cents >= 5):
        cents -= 5
        nickle += 1
    else:
        cents -= 1
        peni += 1

coins = quarter+coin+nickle+peni
print(f"{coins}")