from cs50 import get_int

Height = 0

while (Height > 8 or Height < 1):
    Height = get_int("Height:\n")

for i in range(1, Height+1):
    print(" " * (Height - i), end="")
    print("#" * i, end="  ")
    print("#" * i)
