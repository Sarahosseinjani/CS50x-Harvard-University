#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
typedef uint8_t Byte;
int main(int argc, char *argv[])
{
    if (argc != 2)
    {
        printf("Usage: ./recover image\n");
        return 1;
    }
    FILE *file = fopen(argv[1], "r");
    if (file == NULL)
    {
        printf("Could not open %s.\n", argv[1]);
        return 1;
    }
    Byte buf[512];
    int count = 0;
    FILE *out = NULL;
    char name[8];
    while (true)
    {
        size_t bytes = fread(buf, sizeof(Byte), 512, file);

        if (bytes == 0 && feof(file))
        {
            break;
        }

        bool jpeg = buf[0] == 0xff && buf[1] == 0xd8 && buf[2] == 0xff && (buf[3] & 0xf0) == 0xe0;

        if (jpeg && out != NULL)
        {
            fclose(out);
            count++;
        }

        if (jpeg)
        {
            
            sprintf(name, "%03i.jpg", count);
            out = fopen(name, "w");
        }

        if (out != NULL)
        {
            fwrite(buf, sizeof(Byte), bytes, out);
            
        }
    }
    fclose(out);
    fclose(file);
    return 0;
}
