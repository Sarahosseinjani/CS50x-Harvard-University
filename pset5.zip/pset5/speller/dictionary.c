// Implements a dictionary's functionality

#include <stdbool.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <strings.h>
#include <stdio.h>
#include "dictionary.h"

// Represents a node in a hash table
typedef struct node
{
    char word[LENGTH + 1];
    struct node *next;
}
node;

// Number of buckets in hash table
const unsigned int N = 26;

// Hash table
node *table[N];
int words = 0;
// Returns true if word is in dictionary else false
bool check(const char *word)
{
    node *t = table[hash(word)];
    if (strcasecmp(t->word, word) == 0)
    {
        return true;
    }

    while (t->next != NULL)
    {
        t = t->next;
        if (strcasecmp(t->word, word) == 0)
        {
            return true;
        }
    }

    return false;

}

// Hashes word to a number
unsigned int hash(const char *word)
{
    int num = (int) tolower(word[0]) - 97;
    return num;
}

// Loads dictionary into memory, returning true if successful else false
bool load(const char *dictionary)
{
    FILE *f = fopen(dictionary, "r");
    char *dict = malloc(LENGTH);
    if (dict == NULL)
    {
        return false;
    }

    while (fscanf(f, "%s", dict) != EOF)
    {
        node *n = malloc(sizeof(node));
        if (n == NULL)
        {
            return false;
        }

        strcpy(n->word, dict);
        words++;
        n->next = table[hash(dict)];
        table[hash(dict)] = n;
    }

    fclose(f);
    free(dict);
    return true;
}

// Returns number of words in dictionary if loaded else 0 if not yet loaded
unsigned int size(void)
{

    return words;
}

// Unloads dictionary from memory, returning true if successful else false
bool unload(void)
{
    node *temp;
    node *s;

    for (int i = 0; i < N; i++)
    {
        if (table[i] == NULL)
        {
            continue;
        }

        s = table[i];
        temp = s;

        while (s->next != NULL)
        {
            s = s->next;
            free(temp);
            temp = s;

        }
        free(s);
    }
    return true;

}
